# Quality assurance report

- PASS PNG browser/favicon-16x16.png: 16x16, alpha=True
- PASS PNG browser/favicon-32x32.png: 32x32, alpha=True
- PASS PNG browser/favicon-48x48.png: 48x48, alpha=True
- PASS PNG apple/apple-touch-icon.png: 180x180, alpha=True
- PASS PNG apple/apple-touch-icon-152x152.png: 152x152, alpha=True
- PASS PNG android-pwa/icon-192.png: 192x192, alpha=True
- PASS PNG android-pwa/icon-512.png: 512x512, alpha=True
- PASS PNG android-pwa/icon-192-maskable.png: 192x192, alpha=True
- PASS PNG android-pwa/icon-512-maskable.png: 512x512, alpha=True
- PASS PNG masters/logo-1024.png: 1024x1024, alpha=True
- PASS PNG masters/logo-transparent.png: 2048x2048, alpha=True
- PASS PNG masters/logo-primary-transparent.png: 1024x1024, alpha=True
- PASS PNG masters/logo-dark-mode.png: 1024x1024, alpha=True
- PASS PNG masters/logo-light-mode.png: 1024x1024, alpha=True
- PASS PNG masters/logo-monochrome.png: 1024x1024, alpha=True
- PASS PNG masters/logo-dark-bg.png: 1024x1024, alpha=True
- PASS PNG masters/logo-light-bg.png: 1024x1024, alpha=True
- PASS ICO frames: [(16, 16), (32, 32), (48, 48)]
- PASS SVG XML parse; vector paths are embedded as path geometry (no raster image element).
- PASS web manifest JSON and referenced PWA icon files.
- PASS transparency checks: master PNGs transparent; platform app icons opaque.
- PASS maskable icon safe-zone bounds (central 80% square).

Source logo was supplied as a 1536×1024 raster board. Symbol was isolated from the central artwork; vector contours are a clean trace approximation.
