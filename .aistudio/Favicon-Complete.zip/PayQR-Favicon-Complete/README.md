# PayQR.io Favicon & App Icon Package

This package contains browser favicons, Apple touch icons, Android/PWA icons, master logo treatments, and website integration files.

## Brand colors sampled from the supplied symbol

- Original white: `#F6F4F3`
- Original cyan: `#00E1E3`
- Dark app/background: `#02040A`
- Light background: `#F5F7FA`
- Monochrome ink: `#0B1117`

The original upload was a raster presentation/brand-board image, not a standalone source vector. The central symbol was isolated from the board and the SVG path was traced from that raster. The SVG is genuinely vector-based and scales cleanly, but it is a trace approximation rather than the original editable vector artwork. The 2048 px master is rendered from that traced vector; no claim is made that the source contained 2048 px of native raster detail.

## Folder guide

- `browser/` — SVG, multi-resolution ICO, and 16/32/48 px PNG favicons.
- `apple/` — 180 px and 152 px Apple touch icons.
- `android-pwa/` — 192/512 px standard and maskable PWA icons.
- `masters/` — transparent primary artwork, dark/light treatments, monochrome artwork, and background variants.
- `integration/` — web manifest, HTML head tags, asset manifest, and inventory.

## Typical website installation

1. Copy the package contents (the `browser/`, `apple/`, `android-pwa/`, and `integration/` folders) into your website's `public/` directory, preserving the folder names.
2. Copy the contents of `integration/favicon-integration.html` into your page's `<head>`.
3. Keep `integration/site.webmanifest` at that path, or update the manifest link and icon paths together if you move it.
4. Deploy the site and clear browser/CDN cache if the old favicon remains cached.

The included paths assume the package folders are served from the site root (for example `/browser/favicon.svg`). No website source code has been changed.

## Asset notes

- `favicon.ico` embeds 16×16, 32×32, and 48×48 frames.
- Standard app icons use a solid dark background because platform launch icons generally require an opaque square canvas.
- Maskable icons use additional padding to keep the symbol inside the central safe zone when launchers apply circular, squircle, or other masks.
- Transparent master PNGs preserve alpha. The Apple and PWA app icons are intentionally opaque.
- The symbol-only artwork is used at tiny sizes; there is no wordmark in the supplied logo symbol.

See `integration/asset-inventory.csv` and `integration/asset-manifest.json` for dimensions, formats, transparency, and intended use of every deliverable.

## Quality checks

The package builder verified image decoding, raster dimensions, PNG alpha channels, ICO frame sizes, SVG XML validity, and web manifest JSON validity. Icon previews were rendered at 16, 32, 48, 180, 192, and 512 px. Maskable art was checked against a conservative central safe-zone target.
